#include "./missions.h"

//If the function fetched all wanted data it returns "true", otherwise it return "false"
bool fetchAirportsData(System& airports, vector<string> airportsCodeNames)
{
   bool fetchedAll = false;
   airports.fetchDB(airportsCodeNames, fetchedAll);
   return fetchedAll;
}